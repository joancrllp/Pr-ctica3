package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class apuntarse extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.apuntarse);

        Button btnIrAFiltrarAnuncio = findViewById(R.id.button_filtrar);
        ImageView ivIrAMenu = findViewById(R.id.menu);

        btnIrAFiltrarAnuncio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(apuntarse.this, confirmacio_apuntarse.class);
                startActivity(intent);
            }
        });
        ivIrAMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(apuntarse.this, menu_desplegable.class);
                startActivity(intent);
            }
        });
    }
}

