package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class confirmacio_apuntarse extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.confirmacio_apuntarse);
        Button btnconfirmarApuntarse = findViewById(R.id.btn_confirmar_aceptar);
        ImageView ivIrAMenu = findViewById(R.id.menu);

        btnconfirmarApuntarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(confirmacio_apuntarse.this, pantalla_principal.class);
                startActivity(intent);
            }
        });
        ivIrAMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(confirmacio_apuntarse.this, menu_desplegable.class);
                startActivity(intent);
            }
        });
    }
}

