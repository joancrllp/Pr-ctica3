package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class menu_desplegable extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_desplegable);

        TextView tvCrear_Anuncio = findViewById(R.id.tv_menu_crearAnunci);
        TextView tvMenuAvis = findViewById(R.id.tv_menu_avis);
        TextView tvBuscarAnuncio= findViewById(R.id.tv_menu_BuscarAnunci);
        TextView tvVerPerfil= findViewById(R.id.tv_menu_veurePerfil);

        tvMenuAvis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(menu_desplegable.this, politica_cookies.class);
                startActivity(intent);
            }
        });

        tvBuscarAnuncio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(menu_desplegable.this, filtrar_anuncio.class);
                startActivity(intent);
            }
        });

        tvCrear_Anuncio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(menu_desplegable.this, crear_anuncio.class);
                startActivity(intent);
            }
        });
        tvVerPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(menu_desplegable.this, ver_perfil.class);
                startActivity(intent);
            }
        });
    }
}