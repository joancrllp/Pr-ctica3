package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class pantalla_principal extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_principal);

        Button btnIrAFiltrarAnuncio = findViewById(R.id.button_filtrar);
        ImageView ivIrAMenu = findViewById(R.id.menu);
        btnIrAFiltrarAnuncio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pantalla_principal.this, filtrar_anuncio.class);
                startActivity(intent);
            }
        });


        ivIrAMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pantalla_principal.this, menu_desplegable.class);
                startActivity(intent);
            }
        });
    }
}