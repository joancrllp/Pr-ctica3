package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class politica_cookies extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.politica_cookies);
        Button btnPantallaInicio = findViewById(R.id.btn_cookies_accept);

        ImageView ivIrAMenu = findViewById(R.id.menu);
        btnPantallaInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(politica_cookies.this, pantalla_principal.class);
                startActivity(intent);
            }
        });
        ivIrAMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(politica_cookies.this, menu_desplegable.class);
                startActivity(intent);
            }
        });
    }
}

