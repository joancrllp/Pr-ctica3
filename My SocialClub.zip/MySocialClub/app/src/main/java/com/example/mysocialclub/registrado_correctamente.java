package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class registrado_correctamente extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrado_correctamente);

        Button btnIrAPantallaPrincipal = findViewById(R.id.btn_login_reg);
        btnIrAPantallaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(registrado_correctamente.this, pantalla_principal.class);
                startActivity(intent);
            }
        });
    }
}