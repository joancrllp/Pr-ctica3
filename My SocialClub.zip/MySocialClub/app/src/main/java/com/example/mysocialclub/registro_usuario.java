package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class registro_usuario extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro_usuario);

        Button btnIrRegistroCorrecto = findViewById(R.id.bttn_iniciar_sesion);


        btnIrRegistroCorrecto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(registro_usuario.this, registrado_correctamente.class);
                startActivity(intent);
            }
        });
    }
}