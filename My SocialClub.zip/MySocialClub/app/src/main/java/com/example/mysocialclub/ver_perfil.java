package com.example.mysocialclub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ver_perfil extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.veure_perfil);
        Button btnconfirmarApuntarse = findViewById(R.id.btn_veurePerfil_inicio);

        ImageView ivIrAMenu = findViewById(R.id.menu);
        btnconfirmarApuntarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ver_perfil.this, pantalla_principal.class);
                startActivity(intent);
            }
        });
        ivIrAMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ver_perfil.this, menu_desplegable.class);
                startActivity(intent);
            }
        });
    }
}

